package com.zosh.response;

public class CreatePaymentLinkResponse {
	
	

}
